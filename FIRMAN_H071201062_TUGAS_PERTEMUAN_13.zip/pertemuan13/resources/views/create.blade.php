@extends('layouts.default')

@section('content')
    <section>
    <div class="container">
        <h2 class="text-center">Tambah Data Mahasiswa</h2>

        <!--Awal card Form-->
        <div class="card border-info mt-3">
            <div class="card-header">Form Input Mahasiswa</div>
            <div class="card-body">
                  <form action="{{url('/store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label for="nama">Nama Mahasiswa</label>
                        <input type="text" name="nama" class="form-control" placeholder="masukkan nama anda">
                    </div>

                    <div class="form-group">
                        <label for="nim">NIM</label>
                        <input type="text" name="nim" class="form-control" placeholder="masukan nim anda">
                    </div>

                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                       <textarea class="form-control" name="alamat" placeholder="masukan alamat anda"></textarea>
                    </div>

                    <div class="form-group mt-2">
                        <button type="submit" class = "btn btn-success">Tambah</button>
                    </div>
                    
                    <div class="form-group mt-2">
                        <a href="{{url('/')}}"> Kembali Ke Halaman Utama</a>
                    </div>

                  </form>  
            </div>
        </div>
    </section>
@endsection