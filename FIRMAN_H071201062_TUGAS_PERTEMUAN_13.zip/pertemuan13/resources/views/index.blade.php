@extends('layouts.default')

@section('content')
    <section>
        
        <div class="container mt-5">
            <h1 class="text-center">CRUD LARAVEL</h1>
            <a href="{{url('create')}}" class='btn btn-primary'>Tambah Mahasiswa</a>
                <div class="card border-info mt-3">
                    <div class="card-header">Daftar Mahasiswa</div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Nim</th>
                                <th>Alamat</th>
                                <th>Action</th>
                            </tr>
                            @foreach ($data as $dataMahasiswa)
                                <tr>
                                    <td>{{$dataMahasiswa->id}}</td>
                                    <td>{{$dataMahasiswa->nama}}</td>
                                    <td>{{$dataMahasiswa->nim}}</td>
                                    <td>{{$dataMahasiswa->alamat}}</td>
                                    <td>
                                        <a href="{{url('/show/' . $dataMahasiswa->id)}}" class="btn btn-warning">Edit</a>
                                        <a href="{{url('/destroy/' . $dataMahasiswa->id)}}" class="btn btn-danger">Delete</a>
                                    </td>
                                </tr>
                            @endforeach
                        </table>
                    </div>
                </div>
    </div>
    </section>
@endsection