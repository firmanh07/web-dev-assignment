@extends('layouts.default')

@section('content')
    <section>
        <div class="container">
            <h1 class="text-center">Edit Data Mahasiswa</h1>
            <div class="card border-info mt-3">
                <div class="card-header">Edit Data</div>
                <div class="card-body">
                  <form action="{{url('/update/'.$data->id) }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label for="nama">Nama Mahasiswa</label>
                        <input type="text" name="nama" class="form-control" placeholder="masukkan nama anda" value="{{$data->nama}}">
                    </div>

                    <div class="form-group">
                        <label for="nim">NIM</label>
                        <input type="text" name="nim" class="form-control" placeholder="masukan nim anda" value="{{$data->nim}}">
                    </div>

                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                       <textarea class="form-control" name="alamat" placeholder="masukan alamat anda" >{{$data->alamat}}</textarea>
                    </div>

                    <div class="form-group mt-2">
                        <button type="submit" class = "btn btn-success">Tambah</button>
                    </div>
                    
                    <div class="form-group mt-2">
                        <a href="{{url('/')}}"> Kembali Ke Halaman Utama</a>
                    </div>

                  </form>
                </div>
            </div> 
        </div>
    </section>
@endsection